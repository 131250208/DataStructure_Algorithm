#include<iostream>
#include "MyKit.h"
#include <stdlib.h> 
#include <time.h> 
using namespace std;


#define maxsize 500
//��ӡ��¼
void printRecords(int records[], int n) {
	for (int i = 0; i < n; ++i) {
		cout << records[i] << " ";
	}
}
//��������Ԫ��
void swap(int records[], int i, int j) {
	int temp;
	temp = records[i];
	records[i] = records[j];
	records[j] = temp;
}
//������ɲ���Ԫ��
void giveBirthToSomeSample(int *&records) {
	records = (int *)malloc(maxsize*sizeof(int));

	srand((unsigned)time(NULL));

	for (int i = 0; i < maxsize;++i) {
		records[i] = rand()%1000+1;
	}
}