#ifndef MYKIT_H
#define MYKIT_H
void printRecords(int records[], int n);
void giveBirthToSomeSample(int *&records);
void swap(int records[], int i, int j);
#endif
